"""Kryptologia, laboratorium 4, grupa G5.

Cel: znaleźć a, dla którego pow(g, a, p) == h, dla zadań Z1-Z4.
Uruchomienie: python g5_diffie_hellman.py
Wymagania: Python 3.8 lub nowszy; bez dodatkowych bibliotek.
Kod przygotowano z użyciem AI. Wyniki są obliczane, nie wpisane na stałe.
"""

from math import isqrt, prod
from statistics import median
from time import perf_counter
import platform


# Każdy wiersz zawiera: nazwę zadania, liczbę pierwszą p, generator g i h.
ZADANIA = [
    ("Z1", 37781, 3, 24581),
    ("Z2", 100000127, 5, 5910514),
    ("Z3", 1000000000547, 2, 514634099897),
    ("Z4", 33815155531460793491, 19, 30073559734842340154),
]

POWTORZENIA = 3
LIMIT_TABLICY = 1_100_000  # Wystarcza dla Z3; zapobiega ogromnej tablicy Z4.


def rozklad_na_czynniki(n):
    """Rozkłada n na czynniki pierwsze, np. 20 -> {2: 2, 5: 1}."""
    czynniki = {}
    dzielnik = 2
    while dzielnik * dzielnik <= n:
        while n % dzielnik == 0:
            czynniki[dzielnik] = czynniki.get(dzielnik, 0) + 1
            n //= dzielnik
        # Po liczbie 2 sprawdzamy tylko nieparzystych kandydatów.
        dzielnik += 1 if dzielnik == 2 else 2
    if n > 1:
        czynniki[n] = 1
    return czynniki


def shanks(g, h, p, rzad):
    """Metodą BSGS szuka a w zakresie 0 <= a < rzad, gdzie g^a mod p = h."""
    m = isqrt(rzad - 1) + 1  # Dokładne zaokrąglenie pierwiastka w górę.
    if m > LIMIT_TABLICY:
        raise ValueError(f"Potrzeba {m} wpisów; przekroczono limit tablicy.")

    # Małe kroki: zapisujemy wartość g^j mod p i odpowiadające jej j.
    tablica = {}
    wartosc = 1
    for j in range(m):
        tablica.setdefault(wartosc, j)
        wartosc = wartosc * g % p

    # Duże kroki: sprawdzamy h * g^(-i*m) mod p.
    # pow(x, -1, p) oblicza odwrotność x modulo p.
    krok = pow(pow(g, m, p), -1, p)
    wartosc = h
    for i in range(m):
        if wartosc in tablica:
            a = i * m + tablica[wartosc]
            if a < rzad:
                return a
        wartosc = wartosc * krok % p
    raise ValueError("Nie znaleziono rozwiązania w podanym zakresie.")


def chinskie_tw_reszt(reszty, moduly):
    """Łączy równania a % moduly[i] = reszty[i] w jeden wynik."""
    # Moduły są różnymi potęgami liczb pierwszych, więc są względnie pierwsze.
    iloczyn = prod(moduly)
    wynik = 0
    for reszta, modul in zip(reszty, moduly):
        czesc = iloczyn // modul
        wynik += reszta * czesc * pow(czesc, -1, modul)
    return wynik % iloczyn


def pohlig_hellman(g, h, p):
    """Dzieli problem według czynników p-1 i łączy wyniki przez CRT."""
    rzad = p - 1  # W danych zadania p jest pierwsze, a g jest generatorem.
    czynniki = rozklad_na_czynniki(rzad)
    reszty, moduly = [], []

    for q, wykladnik in czynniki.items():
        reszta = 0
        potega_q = 1
        podstawa = pow(g, rzad // q, p)  # Ta podstawa ma rząd q.

        # Wyznaczamy kolejne cyfry liczby a zapisanej w podstawie q.
        # Dzięki temu dla q^e rozwiązujemy e problemów rzędu q.
        for _ in range(wykladnik):
            pozostalo = h * pow(g, -reszta, p) % p
            cel = pow(pozostalo, rzad // (potega_q * q), p)
            cyfra = shanks(podstawa, cel, p, q)
            reszta += cyfra * potega_q
            potega_q *= q

        reszty.append(reszta)
        moduly.append(potega_q)

    return chinskie_tw_reszt(reszty, moduly)


def zmierz(funkcja, g, h, p, *argumenty):
    """Uruchamia metodę 3 razy, sprawdza wyniki i zwraca medianę czasu."""
    czasy = []
    wyniki = []
    for _ in range(POWTORZENIA):
        start = perf_counter()
        a = funkcja(g, h, p, *argumenty)
        czasy.append(perf_counter() - start)

        # Weryfikacja odbywa się poza pomiarem czasu metody.
        if not 0 <= a < p - 1 or pow(g, a, p) != h:
            raise ValueError("Weryfikacja wyniku nie powiodła się.")
        wyniki.append(a)
    if len(set(wyniki)) != 1:
        raise ValueError("Powtórzenia dały różne wyniki.")
    return wyniki[0], median(czasy), czasy


def main():
    """Rozwiązuje Z1-Z4, porównuje metody i wypisuje wyniki oraz czasy."""
    print(f"GRUPA G5 | Python {platform.python_version()}")
    print(f"Czasy: mediana z {POWTORZENIA} pomiarów, w sekundach.")
    print("Czas PH obejmuje rozkład p-1, podproblemy i CRT.")
    wszystkie_wyniki = []

    for nazwa, p, g, h in ZADANIA:
        print(f"\n{nazwa}: p={p}, g={g}, h={h}")
        czynniki = rozklad_na_czynniki(p - 1)
        opis = " * ".join(f"{q}^{e}" if e > 1 else str(q)
                          for q, e in czynniki.items())
        print(f"p-1 = {opis}")

        # Przy założeniu pierwszości p sprawdzamy, że rząd g wynosi p-1.
        if any(pow(g, (p - 1) // q, p) == 1 for q in czynniki):
            raise ValueError("Podana liczba g nie jest generatorem.")

        wymagane_wpisy = isqrt(p - 2) + 1
        metody = [("Pohlig-Hellman", pohlig_hellman, ())]
        if wymagane_wpisy <= LIMIT_TABLICY:
            metody.insert(0, ("Shanks (BSGS)", shanks, (p - 1,)))
        else:
            print(f"Shanks: POMINIĘTO; tablica wymaga {wymagane_wpisy} wpisów.")

        wyniki_zadania = []
        for nazwa_metody, funkcja, argumenty in metody:
            a, czas, pomiary = zmierz(funkcja, g, h, p, *argumenty)
            wyniki_zadania.append(a)
            print(f"{nazwa_metody}: a={a}; czas={czas:.9f} s")
            print("  Pomiary: " + ", ".join(f"{t:.9f}" for t in pomiary))
            print(f"  Sprawdzenie: pow({g}, {a}, {p}) = {pow(g, a, p)} = h; OK")
            wszystkie_wyniki.append({
                "zadanie": nazwa, "metoda": nazwa_metody, "a": a,
                "czas_s": czas, "pomiary_s": pomiary,
                "wynik_pow": pow(g, a, p), "poprawny": True,
            })

        # Dla Z1-Z3 obie metody muszą zwrócić tę samą liczbę.
        if len(set(wyniki_zadania)) != 1:
            raise ValueError("Metody zwróciły różne wyniki.")
    return wszystkie_wyniki


if __name__ == "__main__":
    main()
