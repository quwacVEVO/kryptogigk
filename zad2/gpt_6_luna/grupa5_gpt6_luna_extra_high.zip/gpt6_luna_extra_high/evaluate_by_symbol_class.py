"""Report final ALFA37 character accuracy by cleartext symbol class."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> None:
    stem = "cipher6_alfa37_30k"
    plain = (ROOT / "data/evaluation/plaintexts" / f"{stem}_plain.txt").read_text(encoding="utf-8")
    candidate = (ROOT / "results" / f"cracked_{stem}.txt").read_text(encoding="utf-8")
    groups = {
        "letters": str.isalpha,
        "digits": str.isdigit,
        "spaces": lambda character: character == " ",
    }
    metrics = {}
    for name, predicate in groups.items():
        positions = [i for i, character in enumerate(plain) if predicate(character)]
        correct = sum(plain[i] == candidate[i] for i in positions)
        metrics[name] = {
            "correct": correct,
            "total": len(positions),
            "accuracy_percent": round(100 * correct / len(positions), 3) if positions else None,
        }
    metrics["overall"] = {
        "correct": sum(a == b for a, b in zip(plain, candidate)),
        "total": len(plain),
        "accuracy_percent": round(
            100 * sum(a == b for a, b in zip(plain, candidate)) / len(plain), 3
        ) if plain else None,
    }
    output = ROOT / "results/symbol_class_metrics.json"
    output.write_text(json.dumps(metrics, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
