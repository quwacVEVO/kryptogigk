"""Evaluate bilingual attack candidates after all blind runs are complete."""
from __future__ import annotations

from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from kryptolib.monoalfabetyczny import get_alphabet  # noqa: E402


def accuracy(candidate: str, plaintext: str) -> float:
    return round(100 * sum(a == b for a, b in zip(candidate, plaintext)) / len(plaintext), 3)


def class_accuracies(candidate: str, plaintext: str) -> dict:
    groups = {
        "letters": str.isalpha,
        "digits": str.isdigit,
        "spaces": lambda char: char == " ",
    }
    output = {}
    for name, predicate in groups.items():
        positions = [i for i, char in enumerate(plaintext) if predicate(char)]
        output[name] = round(
            100 * sum(candidate[i] == plaintext[i] for i in positions) / len(positions), 3
        ) if positions else None
    return output


def main() -> None:
    manifest = json.loads((ROOT / "data/evaluation/manifest.json").read_text(encoding="utf-8"))
    results = []
    for item in manifest:
        stem = Path(item["file"]).stem
        folder = ROOT / "results/multilingual" / stem
        analysis = json.loads((folder / "analysis.json").read_text(encoding="utf-8"))
        plaintext = (ROOT / "data/evaluation/plaintexts" / f"{stem}_plain.txt").read_text(encoding="utf-8")
        ciphertext = (ROOT / "data/ciphertexts" / item["file"]).read_text(encoding="utf-8")
        key = (ROOT / "data/evaluation/keys" / f"{stem}_key.txt").read_text(encoding="utf-8")
        alphabet = get_alphabet(item["mode"])
        actual_map = {cipher: plain for plain, cipher in zip(alphabet, key)}
        inferred = {
            (" " if cipher == "SPACE" else cipher): (" " if plain == "SPACE" else plain)
            for cipher, plain in analysis["best_candidate_mapping_cipher_to_plain"].items()
        }
        observed = set(ciphertext)
        mapped_correct = sum(inferred.get(symbol) == actual_map[symbol] for symbol in observed)
        candidates = {}
        for language in ("pl", "en"):
            candidate = (folder / f"candidate_{language}.txt").read_text(encoding="utf-8")
            candidates[language] = accuracy(candidate, plaintext)
        chosen = analysis["selected_language"]
        chosen_text = (folder / "chosen.txt").read_text(encoding="utf-8")
        item_result = {
            "ciphertext": item["file"],
            "mode": item["mode"],
            "characters": len(plaintext),
            "true_language_after_attack": item["language"],
            "selected_language": chosen,
            "language_selected_correctly": chosen == item["language"],
            "score_pl": analysis["language_hypotheses"]["pl"]["score_per_quadgram"],
            "score_en": analysis["language_hypotheses"]["en"]["score_per_quadgram"],
            "accuracy_if_pl_model": candidates["pl"],
            "accuracy_if_en_model": candidates["en"],
            "selected_candidate_accuracy_percent": accuracy(chosen_text, plaintext),
            "selected_mapping_correct": mapped_correct,
            "selected_mapping_observed_symbols": len(observed),
            "selected_mapping_accuracy_percent": round(100 * mapped_correct / len(observed), 3),
            "both_language_attacks_seconds": analysis["both_language_attacks_elapsed_seconds"],
            "selected_classes_percent": class_accuracies(chosen_text, plaintext),
        }
        refined_path = folder / "chosen_refined.txt"
        refined_meta_path = folder / "analysis_refined.json"
        if refined_path.exists() and refined_meta_path.exists():
            refined = refined_path.read_text(encoding="utf-8")
            refined_meta = json.loads(refined_meta_path.read_text(encoding="utf-8"))
            refined_map = {
                (" " if cipher == "SPACE" else cipher): (" " if plain == "SPACE" else plain)
                for cipher, plain in refined_meta["best_candidate_mapping_cipher_to_plain"].items()
            }
            refined_correct = sum(refined_map.get(symbol) == actual_map[symbol]
                                  for symbol in observed)
            item_result.update({
                "refined_accuracy_percent": accuracy(refined, plaintext),
                "refined_classes_percent": class_accuracies(refined, plaintext),
                "refined_mapping_correct": refined_correct,
                "refined_mapping_accuracy_percent": round(100 * refined_correct / len(observed), 3),
                "refinement_seconds": refined_meta["elapsed_seconds"],
            })
        baseline_path = ROOT / "results" / f"cracked_{stem}.txt"
        if baseline_path.exists():
            baseline_text = baseline_path.read_text(encoding="utf-8")
            item_result["previous_best_accuracy_percent"] = accuracy(baseline_text, plaintext)
        results.append(item_result)

    output = ROOT / "results/multilingual/evaluation.json"
    output.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
