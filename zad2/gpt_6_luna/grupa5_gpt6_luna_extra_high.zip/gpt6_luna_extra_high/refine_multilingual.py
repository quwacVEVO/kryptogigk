"""Give each automatically selected language hypothesis a stronger final search."""
from __future__ import annotations

from pathlib import Path
import json
import math
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from crack import (  # noqa: E402
    build_training, gram_index, local_mapping_margins, make_window_scorer,
    optimize, render_partial, train_ngram_model,
)
from kryptolib.monoalfabetyczny import get_alphabet  # noqa: E402


def mapping_from_analysis(analysis: dict, alphabet: str) -> list[int]:
    ids = {symbol: i for i, symbol in enumerate(alphabet)}
    saved = analysis["best_candidate_mapping_cipher_to_plain"]
    result = []
    for symbol in alphabet:
        plain = saved.get("SPACE" if symbol == " " else symbol,
                          "SPACE" if symbol == " " else symbol)
        result.append(ids[" " if plain == "SPACE" else plain])
    return result


def sampled_score(cipher_ids, mapping, m, scorer, max_windows) -> float:
    window_total = max(1, len(cipher_ids) - 3)
    stride = max(1, math.ceil(window_total / max_windows))
    starts = range(0, window_total, stride)
    values = [scorer(gram_index(cipher_ids, mapping, start, m)) for start in starts]
    return sum(values) / len(values)


def main() -> None:
    paths = sorted((ROOT / "data/ciphertexts").glob("cipher*.txt"))
    summaries = []
    for sample_index, cipher_path in enumerate(paths):
        stem = cipher_path.stem
        mode = "ALFA37" if "_alfa37_" in stem else "ALFA26"
        out_dir = ROOT / "results/multilingual" / stem
        auto_meta = json.loads((out_dir / "analysis.json").read_text(encoding="utf-8"))
        language = auto_meta["selected_language"]
        ciphertext = cipher_path.read_text(encoding="utf-8")
        alphabet = get_alphabet(mode)
        ids = {symbol: i for i, symbol in enumerate(alphabet)}
        cipher_ids = [ids[symbol] for symbol in ciphertext]
        initial = mapping_from_analysis(auto_meta, alphabet)
        lock_label = auto_meta.get("locked_cipher_symbol_to_space")
        lock = None if lock_label is None else ids[lock_label]

        training = build_training(language, mode)
        _, logs, floors, _ = train_ngram_model(training, alphabet)
        scorer = make_window_scorer(len(alphabet), logs, floors)
        before_score = sampled_score(cipher_ids, initial, len(alphabet), scorer, 2_500)
        started = time.perf_counter()
        runs = optimize(
            cipher_ids, initial, len(alphabet), scorer,
            seed=44_200 + sample_index * 353,
            iterations=2_400,
            restarts=5,
            max_windows=2_500,
            greedy_passes=2,
            locked_cipher_symbol=lock,
        )
        elapsed = time.perf_counter() - started
        chosen_run = max(runs[0], (before_score, initial, 0), key=lambda row: row[0])
        best_score, best_mapping, _ = chosen_run
        candidate = "".join(alphabet[best_mapping[ids[symbol]]] for symbol in ciphertext)
        selected_mappings = [mapping for _, mapping, _ in runs[:3]]
        selected_mappings.append(initial)
        margins = local_mapping_margins(
            cipher_ids, best_mapping.copy(), len(alphabet), scorer, max_windows=2_500
        )
        partial, consensus, margin_confirmed = render_partial(
            ciphertext, alphabet, selected_mappings, mode, best_mapping, margins
        )
        (out_dir / "chosen_refined.txt").write_text(candidate, encoding="utf-8")
        (out_dir / "partial_refined.txt").write_text(partial, encoding="utf-8")
        meta = {
            "ciphertext": cipher_path.name,
            "mode": mode,
            "selected_language": language,
            "method": "higher-budget warm-started simulated annealing + greedy refinement",
            "iterations_per_restart": 2_400,
            "restarts": 5,
            "greedy_passes": 2,
            "scored_quadgram_windows": min(max(1, len(ciphertext) - 3), 2_500),
            "locked_cipher_symbol_to_space": lock_label,
            "initial_score_per_quadgram": round(before_score, 6),
            "final_score_per_quadgram": round(best_score, 6),
            "score_gain": round(best_score - before_score, 6),
            "elapsed_seconds": round(elapsed, 4),
            "consensus_symbols": len(consensus),
            "partial_mapping_symbols": len(consensus) + len(margin_confirmed),
            "best_candidate_mapping_cipher_to_plain": {
                ("SPACE" if alphabet[c] == " " else alphabet[c]):
                ("SPACE" if alphabet[best_mapping[c]] == " " else alphabet[best_mapping[c]])
                for c in range(len(alphabet))
            },
            "top_run_scores": [round(score, 6) for score, _, _ in runs[:5]],
        }
        (out_dir / "analysis_refined.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        summaries.append({
            "ciphertext": cipher_path.name,
            "language": language,
            "elapsed_seconds": meta["elapsed_seconds"],
            "score_gain": meta["score_gain"],
            "candidate": str(out_dir / "chosen_refined.txt"),
        })
    print(json.dumps(summaries, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
