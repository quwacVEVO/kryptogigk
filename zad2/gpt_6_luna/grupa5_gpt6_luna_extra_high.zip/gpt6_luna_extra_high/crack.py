"""Blind substitution attack using frequency initialization and n-gram search.

This program reads a ciphertext only. It never opens the separate evaluation
directory containing the original plaintexts and keys.
"""
from __future__ import annotations

import argparse
from collections import Counter
from functools import lru_cache
import json
import math
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from kryptolib import monoalfabetyczny as mono  # noqa: E402
from kryptolib import preprocessing as prep  # noqa: E402
from prepare_samples import TRAINING_TEXT, generated_training_text  # noqa: E402


def build_training(language: str, mode: str) -> str:
    raw_training = TRAINING_TEXT[language] + " " + generated_training_text(language)
    training = prep.przygotuj_tekst(raw_training, mode)
    if mode == "ALFA37":
        # Independent numeric examples give the 10 digit symbols enough
        # n-gram evidence. Values use a different sequence from the test set.
        numeric_examples = []
        for i in range(60):
            item = (i * 37 + 13) % 100
            year = 2001 + (i % 27)
            hour, minute = (i * 7 + 3) % 24, (i * 19 + 5) % 60
            if language == "pl":
                numeric_examples.append(
                    f"W rejestrze pozostaje numer {item} z roku {year}, "
                    f"a notatke zamknieto o {hour:02d}:{minute:02d}."
                )
            else:
                numeric_examples.append(
                    f"The register keeps item {item} from {year}, "
                    f"and the note closed at {hour:02d}:{minute:02d}."
                )
        training += " " + prep.tryb_alfa37(" ".join(numeric_examples))
    return training


def train_ngram_model(training: str, alphabet: str, normalize: bool = False):
    ids = {symbol: i for i, symbol in enumerate(alphabet)}
    counts = {size: Counter() for size in (2, 3, 4)}
    m = len(alphabet)
    encoded = [ids[ch] for ch in training]
    for size in (2, 3, 4):
        for i in range(len(encoded) - size + 1):
            index = 0
            for symbol in encoded[i:i + size]:
                index = index * m + symbol
            counts[size][index] += 1
    if normalize:
        # Normalize counts by the number of observations so that language
        # hypotheses trained on slightly different text lengths are
        # comparable. The denominator adds only a mapping-independent constant
        # to the search objective for any one model.
        denominators = {
            size: max(1, len(encoded) - size + 1)
            for size in counts
        }
        floors = {
            size: math.log(0.08 / denominators[size]) for size in counts
        }
        logs = {
            size: {
                gram: math.log((count + 0.08) / denominators[size])
                for gram, count in table.items()
            }
            for size, table in counts.items()
        }
        return ids, logs, floors, len(training)
    floor = math.log(0.08)
    logs = {
        size: {gram: math.log(count + 0.08) for gram, count in table.items()}
        for size, table in counts.items()
    }
    return ids, logs, floor, len(training)


def make_window_scorer(m, logs, floor):
    # Quadgram score is backed off by overlapping trigrams and bigrams. The
    # memoized composite score makes these extra signals cheap during search.
    @lru_cache(maxsize=200_000)
    def score(quad_index):
        d = quad_index % m
        quad_index //= m
        c = quad_index % m
        quad_index //= m
        b = quad_index % m
        a = quad_index // m
        quad = ((a * m + b) * m + c) * m + d
        tri_left = (a * m + b) * m + c
        tri_right = (b * m + c) * m + d
        bi_1, bi_2, bi_3 = a * m + b, b * m + c, c * m + d
        floor_for = lambda size: floor[size] if isinstance(floor, dict) else floor
        return (
            logs[4].get(quad, floor_for(4))
            + 0.5 * (logs[3].get(tri_left, floor_for(3))
                     + logs[3].get(tri_right, floor_for(3)))
            + 0.25 * (logs[2].get(bi_1, floor_for(2))
                      + logs[2].get(bi_2, floor_for(2))
                      + logs[2].get(bi_3, floor_for(2)))
        )
    return score


def gram_index(source_ids, mapping, start: int, m: int) -> int:
    return (((mapping[source_ids[start]] * m + mapping[source_ids[start + 1]])
             * m + mapping[source_ids[start + 2]])
            * m + mapping[source_ids[start + 3]])


def full_score(source_ids, mapping, m, scorer):
    n = len(source_ids)
    if n < 4:
        return 0.0
    return sum(scorer(gram_index(source_ids, mapping, i, m))
               for i in range(n - 3))


def frequency_start(cipher_ids, alphabet, training_ids, m):
    cipher_counts = Counter(cipher_ids)
    training_counts = Counter(training_ids)
    cipher_rank = sorted(range(m), key=lambda i: (-cipher_counts[i], i))
    plain_rank = sorted(range(m), key=lambda i: (-training_counts[i], i))
    mapping = [0] * m  # cipher symbol id -> candidate plaintext symbol id
    for cipher_symbol, plain_symbol in zip(cipher_rank, plain_rank):
        mapping[cipher_symbol] = plain_symbol
    return mapping


def optimize(cipher_ids, initial, m, scorer, seed, iterations, restarts,
             max_windows, greedy_passes, locked_cipher_symbol=None):
    n = len(cipher_ids)
    all_windows = max(1, n - 3)
    stride = max(1, math.ceil(all_windows / max_windows))
    starts = list(range(0, all_windows, stride))
    window_count = len(starts)
    windows_by_symbol_sets = [set() for _ in range(m)]
    for sample_i, start in enumerate(starts):
        for pos in range(start, start + 4):
            windows_by_symbol_sets[cipher_ids[pos]].add(sample_i)
    windows_by_symbol = [sorted(items) for items in windows_by_symbol_sets]
    pair_windows = [[None] * m for _ in range(m)]
    for a in range(m):
        for b in range(a + 1, m):
            pair_windows[a][b] = sorted(
                windows_by_symbol_sets[a] | windows_by_symbol_sets[b]
            )
    best_runs = []
    rng = random.Random(seed)
    movable = [i for i in range(m) if i != locked_cipher_symbol]

    for restart in range(restarts):
        mapping = initial.copy()
        if restart:
            # Perturb the frequency-based start so independent runs can
            # escape different local maxima.
            swaps = min(12 + restart * 7, m * 2)
            for _ in range(swaps):
                a, b = rng.sample(movable, 2)
                mapping[a], mapping[b] = mapping[b], mapping[a]
        window_scores = [scorer(gram_index(cipher_ids, mapping, start, m))
                         for start in starts]
        current = sum(window_scores)
        for step in range(iterations):
            a, b = rng.sample(movable, 2)
            mapping[a], mapping[b] = mapping[b], mapping[a]
            affected = pair_windows[min(a, b)][max(a, b)]

            delta = 0.0
            proposed_scores = []
            for sample_i in affected:
                start = starts[sample_i]
                new_score = scorer(gram_index(cipher_ids, mapping, start, m))
                proposed_scores.append(new_score)
                delta += new_score - window_scores[sample_i]
            normalized = delta / window_count
            fraction = step / max(1, iterations - 1)
            temperature = 1.35 * (0.025 / 1.35) ** fraction
            if normalized >= 0 or rng.random() < math.exp(normalized / temperature):
                current += delta
                for sample_i, new_score in zip(affected, proposed_scores):
                    window_scores[sample_i] = new_score
            else:
                mapping[a], mapping[b] = mapping[b], mapping[a]

        # Finish each annealing run with a deterministic best-improvement
        # pass over all symbol swaps. This quickly polishes a promising key.
        greedy_steps = 0
        for _ in range(greedy_passes):
            best_delta = 1e-12
            best_pair = None
            best_scores = None
            for a in movable:
                for b in movable:
                    if b <= a:
                        continue
                    affected = pair_windows[a][b]
                    mapping[a], mapping[b] = mapping[b], mapping[a]
                    proposed = [
                        scorer(gram_index(cipher_ids, mapping, starts[i], m))
                        for i in affected
                    ]
                    delta = sum(new - window_scores[i]
                                for i, new in zip(affected, proposed))
                    mapping[a], mapping[b] = mapping[b], mapping[a]
                    if delta > best_delta:
                        best_delta = delta
                        best_pair = (a, b)
                        best_scores = (affected, proposed)
            if best_pair is None:
                break
            a, b = best_pair
            mapping[a], mapping[b] = mapping[b], mapping[a]
            affected, proposed = best_scores
            for i, new_score in zip(affected, proposed):
                window_scores[i] = new_score
            current += best_delta
            greedy_steps += 1

        score = current / window_count
        best_runs.append((score, mapping.copy(), greedy_steps))

    best_runs.sort(key=lambda item: item[0], reverse=True)
    return best_runs


def local_mapping_margins(cipher_ids, mapping, m, scorer, max_windows):
    """Estimate confidence by the score loss from the best single swap."""
    all_windows = max(1, len(cipher_ids) - 3)
    stride = max(1, math.ceil(all_windows / max_windows))
    starts = list(range(0, all_windows, stride))
    by_symbol = [set() for _ in range(m)]
    for sample_i, start in enumerate(starts):
        for pos in range(start, start + 4):
            by_symbol[cipher_ids[pos]].add(sample_i)
    current_scores = [scorer(gram_index(cipher_ids, mapping, start, m)) for start in starts]
    best_alternative = [0.0] * m
    for a in range(m):
        for b in range(a + 1, m):
            affected = by_symbol[a] | by_symbol[b]
            mapping[a], mapping[b] = mapping[b], mapping[a]
            delta = sum(
                scorer(gram_index(cipher_ids, mapping, starts[i], m)) - current_scores[i]
                for i in affected
            ) / len(starts)
            mapping[a], mapping[b] = mapping[b], mapping[a]
            best_alternative[a] = max(best_alternative[a], delta)
            best_alternative[b] = max(best_alternative[b], delta)
    return [max(0.0, -delta) for delta in best_alternative]


def render_partial(ciphertext, alphabet, mappings, mode, best_mapping, margins,
                   confidence_threshold=0.01):
    consensus = {}
    for symbol in alphabet:
        mapped = {mapping[alphabet.index(symbol)] for mapping in mappings}
        if len(mapped) == 1:
            consensus[symbol] = alphabet[next(iter(mapped))]
    known = dict(consensus)
    margin_confirmed = {}
    for symbol in alphabet:
        index = alphabet.index(symbol)
        if symbol not in known and margins[index] >= confidence_threshold:
            known[symbol] = alphabet[best_mapping[index]]
            margin_confirmed[symbol] = known[symbol]
    if mode == "ALFA26":
        return "".join(
            known.get(symbol, symbol).lower() if symbol in known else symbol
            for symbol in ciphertext
        ), consensus, margin_confirmed
    tokens = []
    for symbol in ciphertext:
        if symbol not in known:
            tokens.append("{SP}" if symbol == " " else "{" + symbol + "}")
            continue
        plain = known[symbol]
        if plain == " ":
            tokens.append("<SP>")
        elif plain.isdigit():
            tokens.append(f"[{plain}]")
        else:
            tokens.append(plain.lower())
    return " ".join(tokens), consensus, margin_confirmed


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ciphertext", type=Path)
    parser.add_argument("--mode", required=True, choices=("ALFA26", "ALFA37"))
    parser.add_argument("--language", required=True, choices=("pl", "en"))
    parser.add_argument("--iterations", type=int, default=1_800)
    parser.add_argument("--restarts", type=int, default=2)
    parser.add_argument("--max-windows", type=int, default=5_000,
                        help="maximum sampled quadgram positions per run")
    parser.add_argument("--greedy-passes", type=int, default=2)
    parser.add_argument("--lock-space", action="store_true",
                        help="test the hypothesis that the most common cipher symbol means space")
    parser.add_argument("--seed", type=int, default=520)
    args = parser.parse_args()

    ciphertext = args.ciphertext.read_text(encoding="utf-8")
    alphabet = mono.get_alphabet(args.mode)
    invalid = set(ciphertext) - set(alphabet)
    if invalid:
        raise SystemExit(f"Znaki spoza {args.mode}: {sorted(invalid)}")
    training = build_training(args.language, args.mode)
    ids_by_symbol, log_scores, floor, training_length = train_ngram_model(training, alphabet)
    scorer = make_window_scorer(len(alphabet), log_scores, floor)
    cipher_ids = [ids_by_symbol[ch] for ch in ciphertext]
    training_ids = [ids_by_symbol[ch] for ch in training]
    initial = frequency_start(cipher_ids, alphabet, training_ids, len(alphabet))
    locked_cipher_symbol = None
    if args.mode == "ALFA37" and args.lock_space:
        # In this alphabet, a frequent ciphertext symbol is a useful space
        # candidate. Lock the top-ranked symbol to plaintext space as an
        # explicit, testable hypothesis.
        cipher_counts = Counter(cipher_ids)
        locked_cipher_symbol = max(range(len(alphabet)), key=lambda i: cipher_counts[i])
        space_id = ids_by_symbol[" "]
        old_owner = initial.index(space_id)
        initial[locked_cipher_symbol], initial[old_owner] = space_id, initial[locked_cipher_symbol]

    started = time.perf_counter()
    runs = optimize(cipher_ids, initial, len(alphabet), scorer,
                    args.seed, args.iterations, args.restarts, args.max_windows,
                    args.greedy_passes, locked_cipher_symbol)
    elapsed = time.perf_counter() - started
    # Agreement among the best independent runs is used only to choose what
    # to show as a partial solution; it is not claimed as a probability.
    selected = [mapping for _, mapping, _ in runs[:min(3, len(runs))]]
    best_mapping = runs[0][1]
    margins = local_mapping_margins(cipher_ids, best_mapping.copy(), len(alphabet),
                                    scorer, args.max_windows)
    partial, consensus, margin_confirmed = render_partial(
        ciphertext, alphabet, selected, args.mode, best_mapping, margins
    )
    candidate = "".join(alphabet[best_mapping[ids_by_symbol[ch]]] for ch in ciphertext)

    results_dir = ROOT / "results"
    results_dir.mkdir(exist_ok=True)
    stem = args.ciphertext.stem
    (results_dir / f"cracked_{stem}.txt").write_text(candidate, encoding="utf-8")
    (results_dir / f"partial_{stem}.txt").write_text(partial, encoding="utf-8")
    metadata = {
        "ciphertext": args.ciphertext.name,
        "mode": args.mode,
        "language_assumption": args.language,
        "ciphertext_length": len(ciphertext),
        "training_length": training_length,
        "iterations_per_restart": args.iterations,
        "restarts": args.restarts,
        "greedy_passes": args.greedy_passes,
        "locked_cipher_symbol_to_space": (
            None if locked_cipher_symbol is None else alphabet[locked_cipher_symbol]
        ),
        "greedy_refinement_steps": [steps for _, _, steps in runs],
        "scored_quadgram_windows": min(max(1, len(ciphertext) - 3), args.max_windows),
        "elapsed_seconds": round(elapsed, 4),
        "score_per_quadgram": round(runs[0][0], 6),
        "consensus_symbols": len(consensus),
        "partial_mapping_symbols": len(consensus) + len(margin_confirmed),
        "local_confidence_threshold": 0.01,
        "margin_confirmed_symbols": {
            ("SPACE" if c == " " else c): ("SPACE" if p == " " else p)
            for c, p in margin_confirmed.items()
        },
        "local_mapping_margins": {
            ("SPACE" if alphabet[i] == " " else alphabet[i]): round(margins[i], 6)
            for i in range(len(alphabet))
        },
        "consensus_mapping_cipher_to_plain": {
            ("SPACE" if c == " " else c): ("SPACE" if p == " " else p)
            for c, p in consensus.items()
        },
        "best_candidate_mapping_cipher_to_plain": {
            ("SPACE" if alphabet[i] == " " else alphabet[i]):
            ("SPACE" if alphabet[best_mapping[i]] == " " else alphabet[best_mapping[i]])
            for i in range(len(alphabet))
        },
        "top_run_scores": [round(score, 6) for score, _, _ in runs[:5]],
    }
    (results_dir / f"analysis_{stem}.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({k: metadata[k] for k in (
        "ciphertext", "mode", "language_assumption", "ciphertext_length",
        "elapsed_seconds", "score_per_quadgram", "consensus_symbols", "top_run_scores"
    )}, ensure_ascii=False))


if __name__ == "__main__":
    main()
