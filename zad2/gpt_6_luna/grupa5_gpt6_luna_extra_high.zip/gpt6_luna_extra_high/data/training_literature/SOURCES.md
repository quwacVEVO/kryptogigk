# Źródła korpusu literackiego

Teksty wykorzystano jako publicznie dostępny materiał do niezależnego modelu
językowego dla polskiego szyfru ALFA37. Pobranie jest odtwarzalne skryptem
`fetch_literature.py` z katalogu głównego projektu.

## Atrybucja

- **Władysław Stanisław Reymont, _Chłopi, część pierwsza: Jesień_.** Książka
  pochodzi z serwisu Wolne Lektury:
  <https://wolnelektury.pl/katalog/lektura/chlopi-czesc-pierwsza-jesien/>.
  Użyty plik TXT:
  <https://wolnelektury.pl/media/book/txt/chlopi-czesc-pierwsza-jesien.txt>.
- **Bolesław Prus, _Lalka_.** Książka pochodzi z serwisu Wolne Lektury:
  <https://wolnelektury.pl/katalog/lektura/lalka/>.
  Użyty plik EPUB:
  <https://wolnelektury.pl/media/book/epub/lalka.epub>.

Karty obu tytułów wskazują, że utwory są w domenie publicznej. Materiały
dodatkowe (np. przypisy i motywy literackie) Wolne Lektury udostępniają na
Licencji Wolnej Sztuki 1.3. Zasady wykorzystania i wymogi atrybucji:
<https://wolnelektury.pl/info/zasady-wykorzystania/>. Zachowano nazwy autorów,
tytuły, źródła i informację o modyfikacji.

## Przetwarzanie

Atak korzysta z fragmentów tych tekstów po konwersji KryptoLib do alfabetu
ALFA37: usunięto interpunkcję i diakrytyki, ujednolicono wielkość liter oraz
spacje. Cyfry z tekstów literackich pominięto w modelu; do wszystkich wariantów
dodano tę samą, niezależną próbkę kontekstów liczbowych. Pliki źródłowe
pozostają w formacie pobranym z Wolnych Lektur.

Data pobrania: 2026-10-28.
