"""Compare saved blind candidates against the benchmark after the attacks."""
from __future__ import annotations

from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from kryptolib.monoalfabetyczny import get_alphabet  # noqa: E402


def score_candidate(name: str, candidate: str, analysis: dict, plaintext: str,
                    ciphertext: str, key: str, mode: str) -> dict:
    groups = {
        "letters": str.isalpha,
        "digits": str.isdigit,
        "spaces": lambda char: char == " ",
    }
    class_metrics = {}
    for group, predicate in groups.items():
        positions = [i for i, char in enumerate(plaintext) if predicate(char)]
        class_metrics[group] = {
            "correct": sum(candidate[i] == plaintext[i] for i in positions),
            "total": len(positions),
            "accuracy_percent": round(
                100 * sum(candidate[i] == plaintext[i] for i in positions) / len(positions), 3
            ) if positions else None,
        }
    alphabet = get_alphabet(mode)
    actual_map = {cipher: plain for plain, cipher in zip(alphabet, key)}
    inferred = {
        (" " if cipher == "SPACE" else cipher): (" " if plain == "SPACE" else plain)
        for cipher, plain in analysis["best_candidate_mapping_cipher_to_plain"].items()
    }
    observed = set(ciphertext)
    correct_symbols = sum(inferred.get(symbol) == actual_map[symbol] for symbol in observed)
    return {
        "candidate": name,
        "correct_characters": sum(a == b for a, b in zip(candidate, plaintext)),
        "total_characters": len(plaintext),
        "character_accuracy_percent": round(
            100 * sum(a == b for a, b in zip(candidate, plaintext)) / len(plaintext), 3
        ),
        "observed_symbol_mappings_correct": correct_symbols,
        "observed_symbol_mappings_total": len(observed),
        "mapping_accuracy_percent": round(100 * correct_symbols / len(observed), 3),
        "classes": class_metrics,
    }


def main() -> None:
    stem = "cipher6_alfa37_30k"
    data = ROOT / "data/evaluation"
    plain = (data / "plaintexts" / f"{stem}_plain.txt").read_text(encoding="utf-8")
    key = (data / "keys" / f"{stem}_key.txt").read_text(encoding="utf-8")
    ciphertext = (ROOT / "data/ciphertexts" / f"{stem}.txt").read_text(encoding="utf-8")
    result_dir = ROOT / "results"
    variants = [
        ("synthetic_baseline", result_dir / f"cracked_{stem}.txt",
         result_dir / f"analysis_{stem}.json"),
        ("literature_only", result_dir / "literature/cracked_literature_only.txt",
         result_dir / "literature/analysis_literature_only.json"),
        ("literature_synthetic_mix", result_dir / "literature/cracked_literature_synthetic_mix.txt",
         result_dir / "literature/analysis_literature_synthetic_mix.json"),
        ("literature_10pct", result_dir / "literature/cracked_literature_10pct.txt",
         result_dir / "literature/analysis_literature_10pct.json"),
    ]
    results = []
    for name, candidate_path, analysis_path in variants:
        candidate = candidate_path.read_text(encoding="utf-8")
        analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
        item = score_candidate(name, candidate, analysis, plain, ciphertext, key, "ALFA37")
        if name != "synthetic_baseline":
            item["attack_seconds"] = analysis["elapsed_seconds"]
            item["training_characters"] = analysis["training_characters"]
        results.append(item)
    output = result_dir / "literature" / "evaluation.json"
    output.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n",
                      encoding="utf-8")
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
