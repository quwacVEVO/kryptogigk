"""Frequency analysis for KryptoLib ALFA26 and ALFA37 ciphertexts."""
from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from kryptolib.monoalfabetyczny import get_alphabet  # noqa: E402


def analyze(text: str, mode: str) -> list[tuple[str, int, float]]:
    alphabet = get_alphabet(mode)
    counts = Counter(text)
    total = len(text)
    return sorted(
        ((symbol, counts[symbol], 100 * counts[symbol] / total if total else 0.0)
         for symbol in alphabet),
        key=lambda row: (-row[1], row[0]),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ciphertext", type=Path)
    parser.add_argument("--mode", required=True, choices=("ALFA26", "ALFA37"))
    args = parser.parse_args()
    text = args.ciphertext.read_text(encoding="utf-8")
    if set(text) - set(get_alphabet(args.mode)):
        raise SystemExit("Szyfrogram zawiera znaki spoza wybranego alfabetu.")
    print(f"Plik: {args.ciphertext.name}; tryb: {args.mode}; n={len(text)}")
    print("symbol | liczba | udział")
    for symbol, count, share in analyze(text, args.mode):
        shown = "␠" if symbol == " " else symbol
        print(f"{shown:>6} | {count:6d} | {share:6.2f}%")


if __name__ == "__main__":
    main()
