"""Blind ALFA37 experiment with public-domain Polish literary calibration."""
from __future__ import annotations

from pathlib import Path
import json
import re
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import fetch_literature  # noqa: E402
from crack import make_window_scorer, optimize, train_ngram_model  # noqa: E402
from kryptolib import preprocessing as prep  # noqa: E402
from kryptolib.monoalfabetyczny import get_alphabet  # noqa: E402
from prepare_samples import TRAINING_TEXT, generated_training_text  # noqa: E402


def number_examples() -> str:
    sentences = []
    for i in range(60):
        item = (i * 37 + 13) % 100
        year = 2001 + (i % 27)
        hour, minute = (i * 7 + 3) % 24, (i * 19 + 5) % 60
        sentences.append(
            f"W rejestrze pozostaje numer {item} z roku {year}, "
            f"a notatke zamknieto o {hour:02d}:{minute:02d}."
        )
    return prep.tryb_alfa37(" ".join(sentences))


def plain_map_from_metadata(metadata: dict, alphabet: str) -> list[int]:
    ids = {symbol: i for i, symbol in enumerate(alphabet)}
    mapping = metadata["best_candidate_mapping_cipher_to_plain"]
    targets = []
    for symbol in alphabet:
        target = mapping.get("SPACE" if symbol == " " else symbol,
                             "SPACE" if symbol == " " else symbol)
        targets.append(ids[" " if target == "SPACE" else target])
    return targets


def main() -> None:
    stem = "cipher6_alfa37_30k"
    results = ROOT / "results"
    out_dir = results / "literature"
    out_dir.mkdir(parents=True, exist_ok=True)
    old_meta = json.loads((results / f"analysis_{stem}.json").read_text(encoding="utf-8"))
    alphabet = get_alphabet("ALFA37")
    ids = {symbol: i for i, symbol in enumerate(alphabet)}
    ciphertext_path = ROOT / "data/ciphertexts" / old_meta["ciphertext"]
    ciphertext = ciphertext_path.read_text(encoding="utf-8")
    cipher_ids = [ids[symbol] for symbol in ciphertext]
    initial = plain_map_from_metadata(old_meta, alphabet)
    selected_space = old_meta["selected_space_cipher_symbol"]
    locked_cipher_symbol = ids[selected_space]

    synthetic = prep.tryb_alfa37(
        TRAINING_TEXT["pl"] + " " + generated_training_text("pl")
    )
    parts = fetch_literature.load_literature_parts()
    literary = {
        name: prep.tryb_alfa37(re.sub(r"\d+", " ", raw))
        for name, raw in parts.items()
    }
    if min(len(synthetic), *(len(text) for text in literary.values())) < 22_500:
        raise RuntimeError("Za mało tekstu literackiego do próbki porównawczej")

    number_text = number_examples()
    letter_budget = 45_000
    train_sets = {
        "literature_only": (
            literary["chlopi"][:letter_budget // 2] + " "
            + literary["lalka"][:letter_budget // 2] + " " + number_text
        ),
        "literature_synthetic_mix": (
            synthetic[:letter_budget // 2] + " "
            + literary["chlopi"][:letter_budget // 4] + " "
            + literary["lalka"][:letter_budget // 4] + " " + number_text
        ),
        "literature_10pct": (
            synthetic[:letter_budget * 9 // 10] + " "
            + literary["chlopi"][:letter_budget // 20] + " "
            + literary["lalka"][:letter_budget // 20] + " " + number_text
        ),
    }
    started_all = time.perf_counter()
    summaries = {}
    for index, (variant, training) in enumerate(train_sets.items()):
        _, logs, floor, _ = train_ngram_model(training, alphabet)
        scorer = make_window_scorer(len(alphabet), logs, floor)
        started = time.perf_counter()
        runs = optimize(
            cipher_ids, initial, len(alphabet), scorer,
            seed=39_100 + 131 * index,
            iterations=1_800,
            restarts=4,
            max_windows=2_500,
            greedy_passes=1,
            locked_cipher_symbol=locked_cipher_symbol,
        )
        elapsed = time.perf_counter() - started
        best_mapping = runs[0][1]
        candidate = "".join(alphabet[best_mapping[ids[symbol]]]
                             for symbol in ciphertext)
        (out_dir / f"cracked_{variant}.txt").write_text(candidate, encoding="utf-8")
        metadata = {
            "ciphertext": ciphertext_path.name,
            "method": "warm-started ALFA37 search with independent literary/synthetic n-gram training",
            "training_variant": variant,
            "training_characters": len(training),
            "literary_source_characters": {
                name: len(text) for name, text in literary.items()
            },
            "literary_books": [
                "Władysław Stanisław Reymont, Chłopi, część pierwsza: Jesień",
                "Bolesław Prus, Lalka",
            ],
            "selected_space_cipher_symbol": selected_space,
            "iterations_per_restart": 1_800,
            "restarts": 4,
            "scored_quadgram_windows": 2_500,
            "greedy_passes": 1,
            "elapsed_seconds": round(elapsed, 4),
            "total_experiment_seconds_so_far": round(time.perf_counter() - started_all, 4),
            "score_per_quadgram": round(runs[0][0], 6),
            "best_candidate_mapping_cipher_to_plain": {
                ("SPACE" if alphabet[c] == " " else alphabet[c]):
                ("SPACE" if alphabet[runs[0][1][c]] == " " else alphabet[runs[0][1][c]])
                for c in range(len(alphabet))
            },
            "top_run_scores": [round(score, 6) for score, _, _ in runs[:4]],
        }
        (out_dir / f"analysis_{variant}.json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        summaries[variant] = {
            "training_characters": len(training),
            "elapsed_seconds": metadata["elapsed_seconds"],
            "score_per_quadgram": metadata["score_per_quadgram"],
            "candidate": str(out_dir / f"cracked_{variant}.txt"),
        }
    print(json.dumps({
        "literature_corpus_characters": sum(map(len, literary.values())),
        "variants": summaries,
        "experiment_seconds": round(time.perf_counter() - started_all, 4),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
