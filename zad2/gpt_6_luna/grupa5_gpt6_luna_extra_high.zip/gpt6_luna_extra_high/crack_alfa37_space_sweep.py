"""Alternative ALFA37 attack: compare several ciphertext-to-space hypotheses.

The ordinary attack tests a single frequency-ranked substitution. This version
locks each of the most frequent cipher symbols (and literal ciphertext space,
if present) to plaintext space in turn, then scores each hypothesis using
multistart n-gram optimization. It reads no evaluation keys or cleartexts.
"""
from __future__ import annotations

from collections import Counter
import json
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from crack import (  # noqa: E402
    build_training, frequency_start, local_mapping_margins,
    make_window_scorer, optimize, render_partial, train_ngram_model,
)
from kryptolib.monoalfabetyczny import get_alphabet  # noqa: E402


def main() -> None:
    cipher_path = ROOT / "data/ciphertexts/cipher6_alfa37_30k.txt"
    mode, language = "ALFA37", "pl"
    ciphertext = cipher_path.read_text(encoding="utf-8")
    alphabet = get_alphabet(mode)
    ids_by_symbol = {symbol: i for i, symbol in enumerate(alphabet)}
    cipher_ids = [ids_by_symbol[symbol] for symbol in ciphertext]

    training = build_training(language, mode)
    ids, logs, floor, training_length = train_ngram_model(training, alphabet)
    scorer = make_window_scorer(len(alphabet), logs, floor)
    training_ids = [ids[symbol] for symbol in training]
    frequency_mapping = frequency_start(cipher_ids, alphabet, training_ids, len(alphabet))

    counts = Counter(cipher_ids)
    candidates = [symbol for symbol, _ in counts.most_common(7)]
    literal_space_id = ids_by_symbol[" "]
    if counts[literal_space_id] and literal_space_id not in candidates:
        candidates.append(literal_space_id)

    started = time.perf_counter()
    ranked_runs = []
    hypothesis_summary = []
    for candidate_index, cipher_space in enumerate(candidates):
        initial = frequency_mapping.copy()
        current_owner = initial.index(literal_space_id)
        initial[cipher_space], initial[current_owner] = literal_space_id, initial[cipher_space]
        runs = optimize(
            cipher_ids, initial, len(alphabet), scorer,
            seed=8300 + candidate_index * 97,
            iterations=1_500,
            restarts=2,
            max_windows=2_500,
            greedy_passes=1,
            locked_cipher_symbol=cipher_space,
        )
        hypothesis_summary.append({
            "cipher_symbol_assumed_to_be_space": "SPACE" if alphabet[cipher_space] == " " else alphabet[cipher_space],
            "frequency_percent": round(100 * counts[cipher_space] / len(cipher_ids), 4),
            "best_score": round(runs[0][0], 6),
        })
        ranked_runs.extend((score, mapping, steps, cipher_space)
                           for score, mapping, steps in runs)

    ranked_runs.sort(key=lambda result: result[0], reverse=True)
    best_score, best_mapping, best_steps, selected_space = ranked_runs[0]
    selected_mappings = [mapping for _, mapping, _, _ in ranked_runs[:3]]
    margins = local_mapping_margins(cipher_ids, best_mapping.copy(), len(alphabet),
                                    scorer, max_windows=2_500)
    partial, consensus, margin_confirmed = render_partial(
        ciphertext, alphabet, selected_mappings, mode, best_mapping, margins
    )
    candidate = "".join(alphabet[best_mapping[ids_by_symbol[symbol]]]
                         for symbol in ciphertext)
    elapsed = time.perf_counter() - started

    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    stem = cipher_path.stem
    (results / f"cracked_{stem}.txt").write_text(candidate, encoding="utf-8")
    (results / f"partial_{stem}.txt").write_text(partial, encoding="utf-8")
    metadata = {
        "ciphertext": cipher_path.name,
        "mode": mode,
        "language_assumption": language,
        "ciphertext_length": len(ciphertext),
        "training_length": training_length,
        "method": "ALFA37 space-hypothesis sweep + simulated annealing + greedy refinement",
        "iterations_per_restart": 1_500,
        "restarts_per_hypothesis": 2,
        "greedy_passes": 1,
        "scored_quadgram_windows": 2_500,
        "elapsed_seconds": round(elapsed, 4),
        "space_hypotheses": hypothesis_summary,
        "selected_space_cipher_symbol": "SPACE" if alphabet[selected_space] == " " else alphabet[selected_space],
        "score_per_quadgram": round(best_score, 6),
        "consensus_symbols": len(consensus),
        "partial_mapping_symbols": len(consensus) + len(margin_confirmed),
        "local_confidence_threshold": 0.01,
        "margin_confirmed_symbols": {
            ("SPACE" if cipher_symbol == " " else cipher_symbol):
            ("SPACE" if plain_symbol == " " else plain_symbol)
            for cipher_symbol, plain_symbol in margin_confirmed.items()
        },
        "local_mapping_margins": {
            ("SPACE" if alphabet[i] == " " else alphabet[i]): round(margins[i], 6)
            for i in range(len(alphabet))
        },
        "consensus_mapping_cipher_to_plain": {
            ("SPACE" if cipher_symbol == " " else cipher_symbol):
            ("SPACE" if plain_symbol == " " else plain_symbol)
            for cipher_symbol, plain_symbol in consensus.items()
        },
        "best_candidate_mapping_cipher_to_plain": {
            ("SPACE" if alphabet[i] == " " else alphabet[i]):
            ("SPACE" if alphabet[best_mapping[i]] == " " else alphabet[best_mapping[i]])
            for i in range(len(alphabet))
        },
        "top_run_scores": [round(score, 6) for score, _, _, _ in ranked_runs[:5]],
    }
    (results / f"analysis_{stem}.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "ciphertext": cipher_path.name,
        "elapsed_seconds": metadata["elapsed_seconds"],
        "selected_space_cipher_symbol": metadata["selected_space_cipher_symbol"],
        "space_hypotheses": hypothesis_summary,
        "score_per_quadgram": metadata["score_per_quadgram"],
        "consensus_symbols": metadata["consensus_symbols"],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
