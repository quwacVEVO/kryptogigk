"""Post-attack evaluation. Run only after all blind candidates are saved."""
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from kryptolib import monoalfabetyczny as mono  # noqa: E402


def main() -> None:
    manifest = json.loads((ROOT / "data/evaluation/manifest.json").read_text(encoding="utf-8"))
    report = []
    for item in manifest:
        stem = Path(item["file"]).stem
        key = (ROOT / "data/evaluation/keys" / f"{stem}_key.txt").read_text(encoding="utf-8")
        plain = (ROOT / "data/evaluation/plaintexts" / f"{stem}_plain.txt").read_text(encoding="utf-8")
        cipher = (ROOT / "data/ciphertexts" / item["file"]).read_text(encoding="utf-8")
        candidate_path = ROOT / "results" / f"cracked_{stem}.txt"
        candidate = candidate_path.read_text(encoding="utf-8") if candidate_path.exists() else ""
        analysis_path = ROOT / "results" / f"analysis_{stem}.json"
        analysis = json.loads(analysis_path.read_text(encoding="utf-8")) if analysis_path.exists() else {}

        actual_mapping = {cipher_symbol: plain_symbol for plain_symbol, cipher_symbol in zip(
            mono.get_alphabet(item["mode"]), key
        )}
        inferred_mapping = {
            (" " if c == "SPACE" else c): (" " if p == "SPACE" else p)
            for c, p in analysis.get("best_candidate_mapping_cipher_to_plain", {}).items()
        }
        observed = set(cipher)
        mapped_correct = sum(inferred_mapping.get(c) == actual_mapping[c] for c in observed)
        mapping_accuracy = 100 * mapped_correct / len(observed) if observed else 0.0
        matching = sum(a == b for a, b in zip(plain, candidate))
        accuracy = 100 * matching / len(plain) if plain else 0.0
        exact = candidate == plain
        report.append({
            **item,
            "candidate_exists": candidate_path.exists(),
            "character_accuracy_percent": round(accuracy, 3),
            "observed_symbol_mapping_accuracy_percent": round(mapping_accuracy, 3),
            "exact_full_text_recovery": exact,
            "symbols_observed": len(observed),
            "symbols_mapped_correctly": mapped_correct,
            "attack_seconds": analysis.get("elapsed_seconds"),
            "best_quadgram_score": analysis.get("score_per_quadgram"),
        })
    output = ROOT / "results/evaluation_metrics.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
