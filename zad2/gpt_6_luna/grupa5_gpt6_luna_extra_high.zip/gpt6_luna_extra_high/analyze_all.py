"""Write character frequency tables for all eight ciphertexts."""
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from frequency import analyze  # noqa: E402


def main() -> None:
    manifest = json.loads((ROOT / "data/evaluation/manifest.json").read_text(encoding="utf-8"))
    result = []
    for item in manifest:
        text = (ROOT / "data/ciphertexts" / item["file"]).read_text(encoding="utf-8")
        rows = analyze(text, item["mode"])
        result.append({
            **item,
            "frequencies": [
                {"symbol": "SPACE" if symbol == " " else symbol,
                 "count": count, "percent": round(percent, 4)}
                for symbol, count, percent in rows
            ],
        })
    out = ROOT / "results/frequency_analysis.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Zapisano tabele częstości dla {len(result)} szyfrogramów do {out.relative_to(ROOT)}")
    for item in result:
        top = item["frequencies"][:5]
        formatted = ", ".join(f"{r['symbol']}={r['percent']:.2f}%" for r in top)
        print(f"{item['file']}: {formatted}")


if __name__ == "__main__":
    main()
