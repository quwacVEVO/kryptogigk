"""Plot accuracy for the bilingual automatic language selection experiment."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
rows = json.loads((ROOT / "results/multilingual/evaluation.json").read_text(encoding="utf-8"))
labels = []
values = []
colors = []
for row in rows:
    language = row["true_language_after_attack"]
    mode = row["mode"].replace("ALFA", "")
    length = "2k" if row["characters"] == 2_000 else "30k"
    labels.append(f"{language.upper()}\n{mode}\n{length}")
    values.append(row["refined_accuracy_percent"])
    colors.append("#4c78a8" if language == "en" else "#f28e2b")

fig, ax = plt.subplots(figsize=(11, 5.2))
bars = ax.bar(range(len(rows)), values, color=colors, width=0.72)
ax.set_ylim(0, 105)
ax.set_ylabel("Odzyskane znaki (%)")
ax.set_title("Atak dwujęzyczny: wybór języka i dopracowanie kandydata")
ax.set_xticks(range(len(rows)), labels)
ax.grid(axis="y", alpha=0.25)
for bar, value in zip(bars, values):
    ax.text(bar.get_x() + bar.get_width() / 2, value + 1, f"{value:.2f}%",
            ha="center", va="bottom", fontsize=8)
ax.legend(handles=[
    plt.Rectangle((0, 0), 1, 1, color="#f28e2b", label="Polski"),
    plt.Rectangle((0, 0), 1, 1, color="#4c78a8", label="Angielski"),
], loc="lower left")
fig.text(0.5, 0.01, "Wybór języka był poprawny dla 8/8 szyfrogramów; cyfry ALFA37 nadal są najtrudniejsze.",
         ha="center", fontsize=9)
fig.tight_layout(rect=(0, 0.04, 1, 1))
output = ROOT / "results/multilingual/accuracy.png"
fig.savefig(output, dpi=180, bbox_inches="tight")
print(output)
