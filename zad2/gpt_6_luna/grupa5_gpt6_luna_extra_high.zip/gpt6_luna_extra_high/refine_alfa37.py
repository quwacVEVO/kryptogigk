"""Warm-start a longer blind search from the best ALFA37 space hypothesis."""
from __future__ import annotations

from collections import Counter
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from crack import (  # noqa: E402
    local_mapping_margins, make_window_scorer, optimize, render_partial,
    train_ngram_model,
)
from crack import build_training  # noqa: E402
from kryptolib.monoalfabetyczny import get_alphabet  # noqa: E402


def main() -> None:
    mode, language = "ALFA37", "pl"
    stem = "cipher6_alfa37_30k"
    results = ROOT / "results"
    metadata_path = results / f"analysis_{stem}.json"
    previous = json.loads(metadata_path.read_text(encoding="utf-8"))
    cipher_path = ROOT / "data/ciphertexts" / previous["ciphertext"]
    ciphertext = cipher_path.read_text(encoding="utf-8")
    alphabet = get_alphabet(mode)
    ids = {symbol: i for i, symbol in enumerate(alphabet)}
    cipher_ids = [ids[symbol] for symbol in ciphertext]
    to_char = lambda value: " " if value == "SPACE" else value

    previous_mapping = {
        to_char(cipher_symbol): to_char(plain_symbol)
        for cipher_symbol, plain_symbol in previous["best_candidate_mapping_cipher_to_plain"].items()
    }
    initial = [ids[previous_mapping[symbol]] for symbol in alphabet]
    selected_space = to_char(previous["selected_space_cipher_symbol"])
    locked_cipher_symbol = ids[selected_space]

    training = build_training(language, mode)
    _, logs, floor, training_length = train_ngram_model(training, alphabet)
    scorer = make_window_scorer(len(alphabet), logs, floor)
    started = time.perf_counter()
    runs = optimize(
        cipher_ids, initial, len(alphabet), scorer,
        seed=19_871,
        iterations=3_000,
        restarts=6,
        max_windows=2_500,
        greedy_passes=2,
        locked_cipher_symbol=locked_cipher_symbol,
    )
    elapsed = time.perf_counter() - started
    best_score, best_mapping, greedy_steps = runs[0]
    selected = [mapping for _, mapping, _ in runs[:3]]
    margins = local_mapping_margins(cipher_ids, best_mapping.copy(), len(alphabet),
                                    scorer, max_windows=2_500)
    partial, consensus, margin_confirmed = render_partial(
        ciphertext, alphabet, selected, mode, best_mapping, margins
    )
    candidate = "".join(alphabet[best_mapping[ids[symbol]]] for symbol in ciphertext)
    (results / f"cracked_{stem}.txt").write_text(candidate, encoding="utf-8")
    (results / f"partial_{stem}.txt").write_text(partial, encoding="utf-8")

    metadata = {
        "ciphertext": cipher_path.name,
        "mode": mode,
        "language_assumption": language,
        "ciphertext_length": len(ciphertext),
        "training_length": training_length,
        "method": "warm-started multistart annealing from the best space-sweep mapping",
        "iterations_per_restart": 3_000,
        "restarts": 6,
        "greedy_passes": 2,
        "scored_quadgram_windows": 2_500,
        "elapsed_seconds": round(elapsed, 4),
        "locked_cipher_symbol_to_space": selected_space,
        "selected_space_cipher_symbol": selected_space,
        "score_per_quadgram": round(best_score, 6),
        "consensus_symbols": len(consensus),
        "partial_mapping_symbols": len(consensus) + len(margin_confirmed),
        "local_confidence_threshold": 0.01,
        "margin_confirmed_symbols": {
            ("SPACE" if c == " " else c): ("SPACE" if p == " " else p)
            for c, p in margin_confirmed.items()
        },
        "local_mapping_margins": {
            ("SPACE" if alphabet[i] == " " else alphabet[i]): round(margins[i], 6)
            for i in range(len(alphabet))
        },
        "consensus_mapping_cipher_to_plain": {
            ("SPACE" if c == " " else c): ("SPACE" if p == " " else p)
            for c, p in consensus.items()
        },
        "best_candidate_mapping_cipher_to_plain": {
            ("SPACE" if alphabet[i] == " " else alphabet[i]):
            ("SPACE" if alphabet[best_mapping[i]] == " " else alphabet[best_mapping[i]])
            for i in range(len(alphabet))
        },
        "top_run_scores": [round(score, 6) for score, _, _ in runs[:5]],
    }
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
                             encoding="utf-8")
    print(json.dumps({
        "ciphertext": cipher_path.name,
        "elapsed_seconds": metadata["elapsed_seconds"],
        "score_per_quadgram": metadata["score_per_quadgram"],
        "consensus_symbols": metadata["consensus_symbols"],
        "top_run_scores": metadata["top_run_scores"],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
