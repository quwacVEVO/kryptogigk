"""Fetch attributed Polish literature from the Wolne Lektury API/media files."""
from __future__ import annotations

from html.parser import HTMLParser
from pathlib import Path
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "training_literature"
SOURCES = {
    "chlopi_czesc_pierwsza_jesien.txt":
        "https://wolnelektury.pl/media/book/txt/chlopi-czesc-pierwsza-jesien.txt",
    "lalka.epub": "https://wolnelektury.pl/media/book/epub/lalka.epub",
}


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.ignored = 0

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag in {"script", "style"}:
            self.ignored += 1
        elif tag in {"p", "div", "br", "h1", "h2", "h3", "li"}:
            self.parts.append(" ")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style"} and self.ignored:
            self.ignored -= 1
        elif tag in {"p", "div", "br", "h1", "h2", "h3", "li"}:
            self.parts.append(" ")

    def handle_data(self, data: str) -> None:
        if not self.ignored:
            self.parts.append(data)


def download_sources(refresh: bool = False) -> dict[str, Path]:
    DATA.mkdir(parents=True, exist_ok=True)
    paths = {}
    for name, url in SOURCES.items():
        path = DATA / name
        if refresh or not path.exists():
            request = urllib.request.Request(
                url, headers={"User-Agent": "group5-cryptology-lab/1.0"}
            )
            with urllib.request.urlopen(request, timeout=90) as response:
                path.write_bytes(response.read())
        paths[name] = path
    return paths


def _lalka_text(epub_path: Path) -> str:
    with zipfile.ZipFile(epub_path) as epub:
        container = ET.fromstring(epub.read("META-INF/container.xml"))
        rootfile = next(node for node in container.iter() if node.tag.endswith("rootfile"))
        opf_path = rootfile.attrib["full-path"]
        opf = ET.fromstring(epub.read(opf_path))
        manifest = {
            item.attrib["id"]: item.attrib["href"]
            for item in opf.iter()
            if item.tag.endswith("item")
            and item.attrib.get("media-type", "").lower() in {
                "application/xhtml+xml", "text/html"
            }
        }
        base = Path(opf_path).parent
        spine = next(node for node in opf.iter() if node.tag.endswith("spine"))
        passages = []
        for ref in spine:
            if not ref.tag.endswith("itemref"):
                continue
            href = manifest.get(ref.attrib.get("idref", ""))
            if not href:
                continue
            member = str(base / href)
            parser = _TextExtractor()
            parser.feed(epub.read(member).decode("utf-8-sig", errors="replace"))
            passages.append(" ".join("".join(parser.parts).split()))
        return "\n".join(passages)


def load_literature_parts() -> dict[str, str]:
    paths = download_sources()
    chlopi = paths["chlopi_czesc_pierwsza_jesien.txt"].read_text(encoding="utf-8-sig")
    lalka = _lalka_text(paths["lalka.epub"])
    return {"chlopi": chlopi, "lalka": lalka}


def load_literature() -> tuple[str, dict[str, int]]:
    parts = load_literature_parts()
    return "\n".join(parts.values()), {
        "chlopi_raw_characters": len(parts["chlopi"]),
        "lalka_raw_characters": len(parts["lalka"]),
    }


def main() -> None:
    _, sizes = load_literature()
    print(f"Pobrano źródła do {DATA}")
    print(f"Chłopi, część I: {sizes['chlopi_raw_characters']:,} znaków")
    print(f"Lalka: {sizes['lalka_raw_characters']:,} znaków")


if __name__ == "__main__":
    main()
