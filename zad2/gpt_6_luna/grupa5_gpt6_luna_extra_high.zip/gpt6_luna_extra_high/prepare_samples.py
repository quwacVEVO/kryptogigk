"""Generate the eight blind-attack samples required by lab 2, group 5.

Keys and cleartexts are written to a separate evaluation directory. The
cracker consumes only files from data/ciphertexts and never imports this
module or reads the evaluation directory.
"""
from __future__ import annotations

import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from kryptolib import monoalfabetyczny as mono  # noqa: E402
from kryptolib import preprocessing as prep  # noqa: E402


# The hand-written calibration passages below are separate from the samples.
# A larger procedural calibration corpus is generated later with an
# independent seed; the sample generator also uses an independent test seed.
TRAINING_TEXT = {
    "pl": """
        W czytelni panowala cisza, lecz za oknem slychac bylo ruch ulicy.
        Redaktorka przegladala zapiski, zaznaczala niejasne zdania i porownywala
        je z katalogiem. Gdy brakowalo daty, pytala autora o szczegoly. Tak
        uporzadkowany opis pozwalal innym odtworzyc przebieg wydarzen.
        W niewielkim porcie rybacy naprawiali sieci, a mechanik sprawdzal silnik
        lodzi. Zmiana wiatru mogla opoznic wyprawe, dlatego zaloga obserwowala
        chmury i poziom fal. Po pracy wszyscy wracali do domu ta sama droga.
        Jesienia dzieci zbieraly kasztany, a ogrodnik przycinal galezie drzew.
        Na rynku ustawiano stragany z warzywami, chlebem i domowym serem.
        Sprzedawcy podawali ceny, wazyli towar i pakowali zakupy do papierowych
        toreb. Wieczorem plac pustoszal i sprzatacze zmywali kamienne plyty.
        Nauczyciel wyjasnil zasady doswiadczenia i poprosil klase o cierpliwosc.
        Uczniowie zapisali wynik, powtorzyli pomiar i porownali wartosci.
        Rzetelny zapis byl wazniejszy niz szybka odpowiedz. W razie rozbieznosci
        nalezalo sprawdzic narzedzie, procedure oraz warunki obserwacji.
        W podrozy liczy sie nie tylko odleglosc, ale tez czas i wygoda.
        Rozklad jazdy mozna sprawdzic na stacji albo w punkcie informacji.
        Pasazerowie powinni zachowac bilet do konca przejazdu. Na peronie
        trzeba uwazac na krawedz i sluchac komunikatow obslugi.
        Bibliotekarz ukladal ksiazki wedlug dzialu, nazwiska i roku wydania.
        Czytelnicy mogli zamowic egzemplarz przez katalog albo poprosic o pomoc.
        Zbiory wymagaly suchego pomieszczenia, stalej temperatury i ostroznego
        obchodzenia sie z papierem. Kazdy wolumin mial swoje miejsce.
        """,
    "en": """
        The editor sat by the window, read the notes, and checked every unclear
        sentence against the catalog. When a date was missing, she asked the
        writer for more detail. A careful record helped another reader follow
        the sequence of events without guessing.
        In the small harbor, fishers repaired their nets while a mechanic
        examined a boat engine. A shift in the wind could delay the trip, so
        the crew watched the clouds and the shape of the waves. At the end of
        the day, everyone walked home along the same quiet road.
        In autumn, children collected chestnuts while the gardener trimmed
        branches. Stalls on the square offered vegetables, bread, and local
        cheese. Sellers named the price, weighed each item, and packed the
        groceries in paper bags. After sunset, the square became quiet again.
        The teacher described the experiment and asked the class to be patient.
        Students wrote down the result, repeated the measurement, and compared
        the values. A careful record mattered more than a quick answer. When
        results differed, they checked the tool, the method, and the setting.
        A journey depends on more than distance; time and comfort matter too.
        Travelers can check a timetable at the station or at an information
        desk. Passengers should keep a ticket until the ride ends, stay behind
        the platform edge, and listen for announcements from the staff.
        The librarian sorted books by subject, author, and year of publication.
        Readers could place a request through the catalog or ask for help.
        The collection needed a dry room, stable temperature, and careful
        handling. Every volume belonged in a particular place.
        """,
}


def generated_training_text(language: str, target: int = 45_000,
                            seed: int | None = None) -> str:
    """Build a separate varied language sample for n-gram calibration."""
    default_seed = 8801 if language == "pl" else 8802
    rng = random.Random(default_seed if seed is None else seed)
    if language == "pl":
        people = ["badacz", "redaktorka", "student", "pracownik", "nauczyciel",
                  "opiekunka", "autor", "kierowca", "ogrodnik", "czytelniczka"]
        verbs = ["sprawdza", "opisuje", "porownuje", "zapisuje", "przygotowuje",
                 "czyta", "wybiera", "porzadkuje", "wyjasnia", "odnajduje"]
        infinitives = ["sprawdzic", "opisac", "porownac", "zapisac", "przygotowac",
                       "czytac", "wybrac", "uporzadkowac", "wyjasnic", "odnalezc"]
        objects = ["nowy plan", "krotki raport", "wazna informacje", "dokladny opis",
                   "wynik pomiaru", "poczatek opowiesci", "liste nazw", "stary dokument",
                   "kolejna uwage", "prosty przyklad", "pytanie czytelnika", "wspolny projekt"]
        places = ["archiwum", "biurze", "pokoju", "warsztacie", "ogrodzie",
                  "czytelni", "laboratorium", "niewielkim miescie", "starym domu"]
        times = ["rano", "po pracy", "przed przerwa", "kazdego dnia", "po kilku minutach"]
        parts = []
        length = 0
        while length < target:
            person, verb = rng.choice(people), rng.choice(verbs)
            item, place = rng.choice(objects), rng.choice(places)
            time = rng.choice(times)
            item2 = rng.choice(objects)
            sentence = rng.choice((
                f"{person.capitalize()} {verb} {item} w {place} {time}.",
                f"W {place} mozna {rng.choice(infinitives)} {item} oraz {rng.choice(infinitives)} {item2}.",
                f"Po pracy {person} {verb} {item} i sprawdza {item2}.",
                f"Gdy pojawia sie pytanie, {person} {verb} {item} przed koncem dnia.",
                f"{person.capitalize()} {verb} {item}, a potem porzadkuje {item2}.",
            ))
            parts.append(sentence)
            length += len(sentence) + 1
    else:
        people = ["researcher", "editor", "student", "worker", "teacher", "librarian",
                  "writer", "driver", "gardener", "reader"]
        verbs = ["checks", "describes", "compares", "records", "prepares", "reads",
                 "chooses", "organizes", "explains", "finds"]
        infinitives = ["check", "describe", "compare", "record", "prepare", "read",
                       "choose", "organize", "explain", "find"]
        objects = ["a new plan", "a short report", "important information", "a clear account",
                   "the measured result", "the start of a story", "a list of names",
                   "an old document", "another comment", "a simple example",
                   "a reader question", "a shared project"]
        places = ["the archive", "the office", "the room", "the workshop", "the garden",
                  "the reading room", "the laboratory", "a small town", "an old house"]
        times = ["in the morning", "after work", "before the break", "each day", "after a few minutes"]
        parts = []
        length = 0
        while length < target:
            person, verb = rng.choice(people), rng.choice(verbs)
            item, place = rng.choice(objects), rng.choice(places)
            time = rng.choice(times)
            item2 = rng.choice(objects)
            sentence = rng.choice((
                f"The {person} {verb} {item} in {place} {time}.",
                f"In {place}, a team can {rng.choice(infinitives)} {item} and {rng.choice(infinitives)} {item2}.",
                f"After work, the {person} {verb} {item} and checks {item2}.",
                f"When a question appears, the {person} {verb} {item} before the day ends.",
                f"The {person} {verb} {item}, then writes down {item2}.",
            ))
            parts.append(sentence)
            length += len(sentence) + 1
    return " ".join(parts)


def build_long_text(language: str, mode: str, target: int) -> str:
    # Test and calibration corpora use the same broad sentence generator but
    # independent seeds and independent generated sentences. This is a
    # reproducible train/test split for a small synthetic benchmark, not a
    # claim that this model generalizes to arbitrary natural-language prose.
    seed = 134_000 + (0 if language == "pl" else 50_000)
    raw = generated_training_text(language, target=52_000, seed=seed)
    sentences = raw.split(". ")
    marked = []
    for i, sentence in enumerate(sentences):
        marked.append(sentence)
        if i % 20 == 0:
            item_number = (i * 7) % 100
            year = 2018 + (i % 9)
            hour, minute = i % 24, (i * 13) % 60
            if language == "pl":
                marked.append(
                    f"W rejestrze pozostaje numer {item_number} z roku {year}, "
                    f"a notatke zamknieto o {hour:02d}:{minute:02d}"
                )
            else:
                marked.append(
                    f"The register keeps item {item_number} from {year}, "
                    f"and the note closed at {hour:02d}:{minute:02d}"
                )
    prepared = prep.przygotuj_tekst(". ".join(marked), mode)
    if mode == "ALFA37" and len(prepared) > 1:
        prepared = prepared.replace("  ", " ")
    if len(prepared) < target:
        raise RuntimeError(f"Tekst testowy {language}/{mode} jest za krótki: {len(prepared)}")
    return prepared[:target]


def main() -> None:
    cipher_dir = ROOT / "data" / "ciphertexts"
    plain_dir = ROOT / "data" / "evaluation" / "plaintexts"
    key_dir = ROOT / "data" / "evaluation" / "keys"
    for directory in (cipher_dir, plain_dir, key_dir):
        directory.mkdir(parents=True, exist_ok=True)

    entries = []
    for mode in ("ALFA26", "ALFA37"):
        for language in ("pl", "en"):
            long_text = build_long_text(language, mode, 30_000)
            for length, plaintext in (("2k", long_text[:2_000]), ("30k", long_text)):
                index = 1 + len(entries)
                stem = f"cipher{index}_{mode.lower()}_{length}"
                seed = 20261028 + index * 101
                symbols = list(mono.get_alphabet(mode))
                random.Random(seed).shuffle(symbols)
                key = "".join(symbols)
                ciphertext = mono.encrypt(plaintext, key, mode)
                if len(plaintext) != (2_000 if length == "2k" else 30_000):
                    raise RuntimeError(f"Niepoprawna długość próbki {stem}")
                (cipher_dir / f"{stem}.txt").write_text(ciphertext, encoding="utf-8")
                (plain_dir / f"{stem}_plain.txt").write_text(plaintext, encoding="utf-8")
                (key_dir / f"{stem}_key.txt").write_text(key, encoding="utf-8")
                entries.append({
                    "file": f"{stem}.txt", "mode": mode, "language": language,
                    "length": length, "characters": len(ciphertext), "seed": seed,
                })
    (ROOT / "data" / "evaluation" / "manifest.json").write_text(
        __import__("json").dumps(entries, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Przygotowano {len(entries)} szyfrogramów i tyle samo plików kluczy.")
    for item in entries:
        print(f"{item['file']}: {item['characters']} znaków")


if __name__ == "__main__":
    main()
