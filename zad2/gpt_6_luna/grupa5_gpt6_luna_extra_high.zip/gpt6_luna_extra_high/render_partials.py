"""Render mixed-case partial solutions with local swap-confidence hints."""
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from crack import build_training, local_mapping_margins, train_ngram_model, make_window_scorer  # noqa: E402
from kryptolib.monoalfabetyczny import get_alphabet  # noqa: E402


def main() -> None:
    manifest = json.loads((ROOT / "data/evaluation/manifest.json").read_text(encoding="utf-8"))
    outputs = []
    for item in manifest:
        stem = Path(item["file"]).stem
        analysis_path = ROOT / "results" / f"analysis_{stem}.json"
        if not analysis_path.exists():
            continue
        metadata = json.loads(analysis_path.read_text(encoding="utf-8"))
        mode, language = item["mode"], item["language"]
        alphabet = get_alphabet(mode)
        ids_by_char = {symbol: i for i, symbol in enumerate(alphabet)}
        cipher = (ROOT / "data/ciphertexts" / item["file"]).read_text(encoding="utf-8")
        to_char = lambda s: " " if s == "SPACE" else s
        best = {to_char(k): to_char(v)
                for k, v in metadata["best_candidate_mapping_cipher_to_plain"].items()}
        best_list = [ids_by_char[best[ch]] for ch in alphabet]
        consensus = {to_char(k): to_char(v)
                     for k, v in metadata.get("consensus_mapping_cipher_to_plain", {}).items()}

        training = build_training(language, mode)
        ids, logs, floor, _ = train_ngram_model(training, alphabet)
        scorer = make_window_scorer(len(alphabet), logs, floor)
        margins = local_mapping_margins([ids[ch] for ch in cipher], best_list.copy(),
                                        len(alphabet), scorer,
                                        metadata.get("scored_quadgram_windows", 5000))
        known = dict(consensus)
        margin_confirmed = {}
        for i, symbol in enumerate(alphabet):
            if symbol not in known and margins[i] >= 0.01:
                known[symbol] = best[symbol]
                margin_confirmed[symbol] = best[symbol]

        if mode == "ALFA26":
            partial = "".join(known[s].lower() if s in known else s for s in cipher)
        else:
            tokens = []
            for symbol in cipher:
                if symbol not in known:
                    tokens.append("{SP}" if symbol == " " else "{" + symbol + "}")
                elif known[symbol] == " ":
                    tokens.append("<SP>")
                elif known[symbol].isdigit():
                    tokens.append(f"[{known[symbol]}]")
                else:
                    tokens.append(known[symbol].lower())
            partial = " ".join(tokens)
        (ROOT / "results" / f"partial_{stem}.txt").write_text(partial, encoding="utf-8")
        metadata["local_confidence_threshold"] = 0.01
        metadata["partial_mapping_symbols"] = len(known)
        metadata["margin_confirmed_symbols"] = {
            ("SPACE" if c == " " else c): ("SPACE" if p == " " else p)
            for c, p in margin_confirmed.items()
        }
        metadata["local_mapping_margins"] = {
            ("SPACE" if alphabet[i] == " " else alphabet[i]): round(margins[i], 6)
            for i in range(len(alphabet))
        }
        analysis_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
                                 encoding="utf-8")
        outputs.append((stem, len(known)))
    for stem, count in outputs:
        print(f"{stem}: {count} symboli w zapisie częściowym")


if __name__ == "__main__":
    main()
