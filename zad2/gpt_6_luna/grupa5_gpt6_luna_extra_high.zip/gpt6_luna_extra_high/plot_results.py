"""Create an exportable comparison chart from post-attack metrics."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent


def main() -> None:
    metrics = json.loads((ROOT / "results/evaluation_metrics.json").read_text(encoding="utf-8"))
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 4.8), sharey=True)
    for axis, mode in zip(axes, ("ALFA26", "ALFA37")):
        rows = [row for row in metrics if row["mode"] == mode and row["language"] == "pl"]
        rows.sort(key=lambda row: 0 if row["length"] == "2k" else 1)
        values = [row["character_accuracy_percent"] for row in rows]
        bars = axis.bar([row["length"] for row in rows], values, width=0.58)
        axis.set_title(mode)
        axis.set_xlabel("Długość szyfrogramu")
        axis.set_ylim(0, 108)
        axis.grid(axis="y", alpha=0.25)
        axis.set_axisbelow(True)
        for bar, value in zip(bars, values):
            axis.text(bar.get_x() + bar.get_width() / 2,
                      max(value + 1.5, 2.0), f"{value:.2f}%",
                      ha="center", va="bottom", fontsize=9)
    axes[0].set_ylabel("Poprawnie odzyskane znaki (%)")
    fig.suptitle("Wynik ślepego ataku na polskie próbki", fontsize=13)
    fig.text(0.5, 0.01,
             "ALFA37/30k po przeszukaniu hipotez spacji i rozszerzeniu modelu liczb.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, 0.05, 1, 0.94))
    out = ROOT / "results/accuracy_comparison.png"
    fig.savefig(out, dpi=180, bbox_inches="tight")
    print(out)


if __name__ == "__main__":
    main()
