"""Blindly try both Polish and English n-gram models for one or all samples."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from crack import (  # noqa: E402
    build_training, frequency_start, local_mapping_margins,
    make_window_scorer, optimize, render_partial, train_ngram_model,
)
from kryptolib.monoalfabetyczny import get_alphabet  # noqa: E402


def mode_from_name(path: Path) -> str:
    name = path.stem.lower()
    if "_alfa26_" in name:
        return "ALFA26"
    if "_alfa37_" in name:
        return "ALFA37"
    raise ValueError(f"Nie można ustalić trybu z nazwy pliku: {path.name}")


def attack_file(cipher_path: Path, mode: str, iterations: int, restarts: int,
                max_windows: int, greedy_passes: int, seed: int) -> dict:
    ciphertext = cipher_path.read_text(encoding="utf-8")
    alphabet = get_alphabet(mode)
    ids_by_symbol = {symbol: i for i, symbol in enumerate(alphabet)}
    invalid = set(ciphertext) - set(alphabet)
    if invalid:
        raise ValueError(f"Znaki spoza {mode}: {sorted(invalid)}")
    cipher_ids = [ids_by_symbol[symbol] for symbol in ciphertext]
    counts = Counter(cipher_ids)
    locked_cipher_symbol = None
    if mode == "ALFA37":
        locked_cipher_symbol = counts.most_common(1)[0][0]

    hypotheses = {}
    for language_index, language in enumerate(("pl", "en")):
        training = build_training(language, mode)
        train_ids, logs, floors, training_length = train_ngram_model(
            training, alphabet, normalize=True
        )
        scorer = make_window_scorer(len(alphabet), logs, floors)
        training_ids = [train_ids[symbol] for symbol in training]
        initial = frequency_start(cipher_ids, alphabet, training_ids, len(alphabet))
        if locked_cipher_symbol is not None:
            space_id = ids_by_symbol[" "]
            old_owner = initial.index(space_id)
            initial[locked_cipher_symbol], initial[old_owner] = space_id, initial[locked_cipher_symbol]

        started = time.perf_counter()
        runs = optimize(
            cipher_ids, initial, len(alphabet), scorer,
            seed=seed + language_index * 10_007,
            iterations=iterations,
            restarts=restarts,
            max_windows=max_windows,
            greedy_passes=greedy_passes,
            locked_cipher_symbol=locked_cipher_symbol,
        )
        elapsed = time.perf_counter() - started
        hypotheses[language] = {
            "mapping": runs[0][1],
            "runs": runs,
            "scorer": scorer,
            "training_length": training_length,
            "elapsed_seconds": round(elapsed, 4),
            "score_per_quadgram": round(runs[0][0], 6),
        }

    chosen_language = max(
        hypotheses, key=lambda language: hypotheses[language]["score_per_quadgram"]
    )
    chosen = hypotheses[chosen_language]
    best_mapping = chosen["mapping"]
    candidate = "".join(
        alphabet[best_mapping[ids_by_symbol[symbol]]] for symbol in ciphertext
    )
    selected_mappings = [mapping for _, mapping, _ in chosen["runs"][:3]]
    margins = local_mapping_margins(
        cipher_ids, best_mapping.copy(), len(alphabet), chosen["scorer"], max_windows
    )
    partial, consensus, margin_confirmed = render_partial(
        ciphertext, alphabet, selected_mappings, mode, best_mapping, margins
    )

    output_dir = ROOT / "results" / "multilingual" / cipher_path.stem
    output_dir.mkdir(parents=True, exist_ok=True)
    for language, result in hypotheses.items():
        candidate_i = "".join(
            alphabet[result["mapping"][ids_by_symbol[symbol]]]
            for symbol in ciphertext
        )
        (output_dir / f"candidate_{language}.txt").write_text(candidate_i, encoding="utf-8")
    (output_dir / "chosen.txt").write_text(candidate, encoding="utf-8")
    (output_dir / "partial.txt").write_text(partial, encoding="utf-8")

    score_by_language = {
        language: {
            "training_characters": result["training_length"],
            "score_per_quadgram": result["score_per_quadgram"],
            "elapsed_seconds": result["elapsed_seconds"],
            "top_run_scores": [round(score, 6) for score, _, _ in result["runs"][:3]],
        }
        for language, result in hypotheses.items()
    }
    metadata = {
        "ciphertext": cipher_path.name,
        "mode": mode,
        "ciphertext_length": len(ciphertext),
        "method": "blind dual-language n-gram attacks with normalized cross-language scoring",
        "selected_language": chosen_language,
        "language_hypotheses": score_by_language,
        "language_score_margin_pl_minus_en": round(
            score_by_language["pl"]["score_per_quadgram"]
            - score_by_language["en"]["score_per_quadgram"], 6
        ),
        "iterations_per_restart": iterations,
        "restarts_per_language": restarts,
        "greedy_passes": greedy_passes,
        "scored_quadgram_windows": min(max(1, len(ciphertext) - 3), max_windows),
        "locked_cipher_symbol_to_space": (
            None if locked_cipher_symbol is None else alphabet[locked_cipher_symbol]
        ),
        "selected_language_elapsed_seconds": chosen["elapsed_seconds"],
        "both_language_attacks_elapsed_seconds": round(sum(
            result["elapsed_seconds"] for result in hypotheses.values()
        ), 4),
        "consensus_symbols": len(consensus),
        "partial_mapping_symbols": len(consensus) + len(margin_confirmed),
        "best_candidate_mapping_cipher_to_plain": {
            ("SPACE" if alphabet[c] == " " else alphabet[c]):
            ("SPACE" if alphabet[best_mapping[c]] == " " else alphabet[best_mapping[c]])
            for c in range(len(alphabet))
        },
        "candidate_files": {
            language: f"candidate_{language}.txt" for language in hypotheses
        },
    }
    (output_dir / "analysis.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return {
        "ciphertext": cipher_path.name,
        "mode": mode,
        "length": len(ciphertext),
        "selected_language": chosen_language,
        "score_pl": score_by_language["pl"]["score_per_quadgram"],
        "score_en": score_by_language["en"]["score_per_quadgram"],
        "elapsed_seconds": metadata["both_language_attacks_elapsed_seconds"],
        "output": str(output_dir / "chosen.txt"),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ciphertext", type=Path, nargs="?", help="pojedynczy szyfrogram")
    parser.add_argument("--all", action="store_true", help="zaatakuj wszystkie pliki ciphertext")
    parser.add_argument("--mode", choices=("ALFA26", "ALFA37"),
                        help="tryb; przy --all ustalany z nazwy pliku")
    parser.add_argument("--iterations", type=int, default=1_800)
    parser.add_argument("--restarts", type=int, default=3)
    parser.add_argument("--max-windows", type=int, default=2_500)
    parser.add_argument("--greedy-passes", type=int, default=1)
    parser.add_argument("--seed", type=int, default=9_711)
    args = parser.parse_args()
    if (args.all and args.ciphertext) or (not args.all and not args.ciphertext):
        parser.error("Podaj jeden szyfrogram albo użyj --all.")
    if args.all:
        paths = sorted((ROOT / "data/ciphertexts").glob("cipher*.txt"))
    else:
        paths = [args.ciphertext]
    outputs = []
    for path_index, path in enumerate(paths):
        mode = args.mode or mode_from_name(path)
        outputs.append(attack_file(
            path, mode, args.iterations, args.restarts, args.max_windows,
            args.greedy_passes, args.seed + path_index * 101,
        ))
    print(json.dumps(outputs, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
