# Grupa 5 — GPT-6 Luna Extra High

Pakiet zawiera generator próbek, analizę częstości, automatyczne próby łamania,
ewaluację po zakończeniu ataku oraz sprawozdanie.

## Uruchomienie

Wymagany jest Python 3. Używane są moduły standardowe oraz dołączona kopia
KryptoLib z projektu. `matplotlib` jest potrzebny wyłącznie do wygenerowania
wykresu.

```bash
python prepare_samples.py
python analyze_all.py
python crack.py data/ciphertexts/cipher1_alfa26_2k.txt --mode ALFA26 --language pl
python crack.py data/ciphertexts/cipher2_alfa26_30k.txt --mode ALFA26 --language pl --iterations 1200 --restarts 6 --max-windows 3000 --greedy-passes 2
python crack.py data/ciphertexts/cipher5_alfa37_2k.txt --mode ALFA37 --language pl --iterations 900 --restarts 4 --max-windows 2500 --greedy-passes 1
python crack_alfa37_space_sweep.py
python refine_alfa37.py
python fetch_literature.py
python attack_with_literature.py
python evaluate_literature_attack.py
python crack_multilingual.py --all --iterations 1200 --restarts 2 --max-windows 2000 --greedy-passes 1
python refine_multilingual.py
python evaluate_multilingual.py
python plot_multilingual.py
python render_partials.py
python evaluate_after_cracking.py
python evaluate_by_symbol_class.py
python plot_results.py
```

`crack.py` odczytuje wyłącznie podany szyfrogram i jawny model językowy
z `prepare_samples.py`; nie otwiera `data/evaluation/`. Ewaluator, który czyta
klucze i teksty jawne, uruchamia się dopiero po zapisaniu kandydatów.
`crack_alfa37_space_sweep.py` i `refine_alfa37.py` również czytają tylko
szyfrogram oraz model językowy. Wyniki wcześniejszego, słabszego ataku są
zachowane w `results/baseline_alfa37/`, `results/space_sweep_v1/` i
`results/space_sweep_v2/`.

`fetch_literature.py` pobiera dwa utwory z Wolnych Lektur (wymaga dostępu do
Internetu). `attack_with_literature.py` korzysta z szyfrogramu, publicznych
tekstów i mapowania z poprzedniego ataku, lecz nie odczytuje ewaluacyjnych
kluczy ani tekstów jawnych. `evaluate_literature_attack.py` czyta je dopiero
po zapisaniu kandydatów. Atrybucja i warunki licencji są w
`data/training_literature/SOURCES.md`.

`crack_multilingual.py --all` uruchamia ślepe próby z polskim i angielskim
modelem dla każdego szyfrogramu, porównuje znormalizowane wyniki n-gramów i
wybiera język z wyższym wynikiem. `refine_multilingual.py` zwiększa budżet
przeszukiwania wybranego modelu. Oba skrypty działają wyłącznie na
`data/ciphertexts/`; ewaluacja prawdziwego języka, tekstów i kluczy następuje
dopiero w `evaluate_multilingual.py` po zapisaniu kandydatów.

## Struktura

- `results/multilingual/` — wybór języka, kandydaci i ewaluacja ośmiu próbek
  polskich i angielskich.
- `data/training_literature/` — źródła i atrybucja publicznej literatury.
- `data/ciphertexts/` — osiem szyfrogramów do ataku.
- `data/evaluation/plaintexts/`, `data/evaluation/keys/` — materiały do
  końcowej ewaluacji, oddzielone od wejścia ataku.
- `results/` — tabele częstości, kandydaci, częściowe deszyfrowania, metryki
  i wykres.
- `report_grupa5.md` — sprawozdanie.
